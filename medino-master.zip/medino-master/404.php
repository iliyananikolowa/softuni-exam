<?php get_header(); ?>
     <section class="text-center section-padding">
         <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <h1 class="title"><?php _e( 'Sorry, no posts found', 'softuni'); ?></h1>
                </div>
            </div>
        </div>   
    </section>

    <!-- Hotline Area Starts -->
    <section class="hotline-area text-center section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2>Emergency hotline</h2>
                    <span>(+01) – 256 567 550</span>
                    <p class="pt-3">We provide 24/7 customer support. Please feel free to contact us <br>for emergency case.</p>
                </div>
            </div>
        </div>
    </section>
    <!-- Hotline Area End -->
   
<?php get_footer(); ?>