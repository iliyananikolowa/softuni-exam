<?php
/**
 * Template Name: Blog Homepage
 */

?>

<?php get_header(); ?>

<!-- WP_QUERY Meta-->

<?php
$medino_args = array(
    'post_type'         => 'medino',
    'post_status'       => 'publish',
    'posts_per_page'    => 9,
    'meta_query'=>array(
        array(
            'key'       => 'show',
            'value'     => 1,
            'compare'   => '=',
        ),
    )

);

$medino_query = new WP_Query ( $medino_args );
?>
        
   
    <!-- Blog Area Starts -->
    <section class="-area section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-3">
                    <div class="section-top text-center">
                        <h2><?php the_title(); ?></h2>
                    </div>
                </div>
            </div>

       
            <div class="row">
                <?php if ( $medino_query->have_posts() ) : ?>
                    <?php while( $medino_query->have_posts() ) : $medino_query->the_post(); ?>
                        <div class="col-sm-4">
                            <div class="news-img">                                                        
                                <img src="<?php echo MEDINO_ASSETS_URL; ?>/images/default.jpg" alt="" class="img-fluid">                                                               
                                <h3><a href="blog-details.html"><?php the_title(); ?></a></h3>
                                <p>Elementum libero hac leo integer. Risus hac part duriw feugiat litora cursus hendrerit bibendum per person on elit.Tempus inceptos posuere me.</p>                               
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php endif; ?>
             </div>
    </section>
    <!-- News Area Starts -->

<?php get_footer(); ?>