<?php


if ( ! defined( 'MEDINO_ASSETS_VERSION' ) ) {
    define( 'MEDINO_ASSETS_VERSION', '0.1' );
}

if ( ! defined( 'MEDINO_ASSETS_URL' ) ) {
    define( 'MEDINO_ASSETS_URL', get_template_directory_uri() . '/assets/');
}

//Generate theme support elements

add_theme_support( 'title-tag' );
add_theme_support( 'post-tumbnails' );

/**
 *  Function that enqueues all of our assets
 * 
 * @return void
 */

function medino_enqueue_assets() {
   

    // Theme Styles
    
    wp_enqueue_style( 'bootstrap-4.1.3.min', MEDINO_ASSETS_URL . '/css/bootstrap-4.1.3.min.css', array(), MEDINO_ASSETS_VERSION );
    wp_enqueue_style( 'font-awesome-4.7.0.min', MEDINO_ASSETS_URL . '/css/font-awesome-4.7.0.min.css', array(), MEDINO_ASSETS_VERSION );
    wp_enqueue_style( 'owl-carousel.min', MEDINO_ASSETS_URL . '/css/owl-carousel.min.css', array(), MEDINO_ASSETS_VERSION );
    wp_enqueue_style( 'jquery.datetimepicker.min', MEDINO_ASSETS_URL . '/css/jquery.datetimepicker.min.css', array(), MEDINO_ASSETS_VERSION );
    wp_enqueue_style( 'linearicons', MEDINO_ASSETS_URL . '/css/linearicons.css', array(), MEDINO_ASSETS_VERSION );
    wp_enqueue_style( 'style', MEDINO_ASSETS_URL . '/css/style.css', array(), MEDINO_ASSETS_VERSION );
    

   
    //Theme Scripts

    wp_enqueue_script('jquery-2.2.4.min', MEDINO_ASSETS_URL . '/js/vendor/jquery-2.2.4.min.js' , array('jquery'), MEDINO_ASSETS_VERSION , array());
    wp_enqueue_script('bootstrap-4.1.3.min', MEDINO_ASSETS_URL . '/js/vendor/bootstrap-4.1.3.min.js' , array('jquery'), MEDINO_ASSETS_VERSION , array());
    wp_enqueue_script('wow.min', MEDINO_ASSETS_URL . '/js/vendor/wow.min.js' , array('jquery'), MEDINO_ASSETS_VERSION , array());
    wp_enqueue_script('owl-carousel.min', MEDINO_ASSETS_URL . '/js/vendor/owl-carousel.min.js' , array('jquery'), MEDINO_ASSETS_VERSION , array());
    wp_enqueue_script('jquery.datetimepicker.full.min', MEDINO_ASSETS_URL . '/js/vendor/jquery.datetimepicker.full.min.js' , array('jquery'), MEDINO_ASSETS_VERSION , array());
    wp_enqueue_script('jquery.nice-select.min', MEDINO_ASSETS_URL . '/js/vendor/jquery.nice-select.min.js' , array('jquery'), MEDINO_ASSETS_VERSION , array());
    wp_enqueue_script('superfish.min', MEDINO_ASSETS_URL . '/js/vendor/superfish.min.js' , array('jquery'), MEDINO_ASSETS_VERSION , array());
    wp_enqueue_script('main', MEDINO_ASSETS_URL . '/js/main.js' , array('jquery'), MEDINO_ASSETS_VERSION , array());
   
  
}

add_action( 'wp_enqueue_scripts', 'medino_enqueue_assets' );

/**
 * Register navigation menus
 * 
 * @return void
 */

function medino_register_nav_menus() {
    register_nav_menus(
      array(
        'header-menu' => __( 'Header Menu', 'softuni' ),
       )
     );
   }
   add_action( 'init' , 'medino_register_nav_menus' );


   /* Register the widgets. */
   
    function medino_sidebars() {

      /* Register sidebar. */
        register_sidebar(
          array(
              'id' => 'sidebar1',
              'name' => __( 'Primary Sidebar 1' ),
              'description' => __( 'A short description of the sidebar.' ),
              'before_widget' => '<div id="%1$s" class="widget %2$s">',
              'after_widget' => '</div>',
              'before_title' => '<h3 class="widget-title">',
              'after_title' => '</h3>',
          )
        );

        register_sidebar(
          array(
              'id' => 'sidebar2',
              'name' => __( 'Primary Sidebar 2' ),
              'description' => __( 'A short description of the sidebar.' ),
              'before_widget' => '<div id="%1$s" class="widget %2$s">',
              'after_widget' => '</div>',
              'before_title' => '<h3 class="widget-title">',
              'after_title' => '</h3>',
          )
        );

        register_sidebar(
          array(
              'id' => 'sidebar3',
              'name' => __( 'Primary Sidebar 3' ),
              'description' => __( 'A short description of the sidebar.' ),
              'before_widget' => '<div id="%1$s" class="widget %2$s">',
              'after_widget' => '</div>',
              'before_title' => '<h3 class="widget-title">',
              'after_title' => '</h3>',
          )
        );


      }
        add_action( 'widgets_init', 'medino_sidebars' );
    
