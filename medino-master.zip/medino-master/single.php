<?php get_header(); ?>

    <?php if ( have_posts() ) : ?>

        <?php while( have_posts() ) : the_post(); ?>

           <!-- Banner Area Starts -->
           <section class="banner-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5">
                        <h4>Caring for better life</h4>
                        <h1>Leading the way in medical excellence</h1>
                        <p>Earth greater grass for good. Place for divide evening yielding them that. Creeping beginning over gathered brought.</p>
                    </div>
                </div>
            </div>
        </section>
        <!-- Banner Area End -->
        <section class="text-center section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <h1 class="title"><?php the_title(); ?></h1>
                    </div>
                 </div>
             </div>
                 
        <section class="text-center section-padding">
                <div class="container">
                    <div class="row">
                        <div class="p-large"><?php the_content(); ?>
                        </div>
                    </div>
                 </div>
            <!-- Feature Area Starts -->

            <section class="feature-area section-padding">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-3 col-md-6">
                            <div class="single-feature text-center item-padding">
                                <img src="<?php echo MEDINO_ASSETS_URL; ?>/images/feature1.png" alt="">
                                <h3>advance technology</h3>
                                <p class="pt-3">Creeping for female light years that lesser can't evening heaven isn't bearing tree appear</p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="single-feature text-center item-padding mt-4 mt-md-0">
                                <img src="<?php echo MEDINO_ASSETS_URL; ?>/images/feature2.png" alt="">
                                <h3>comfortable place</h3>
                                <p class="pt-3">Creeping for female light years that lesser can't evening heaven isn't bearing tree appear</p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="single-feature text-center item-padding mt-4 mt-lg-0">
                                <img src="<?php echo MEDINO_ASSETS_URL; ?>/images/feature3.png" alt="">
                                <h3>quality equipment</h3>
                                <p class="pt-3">Creeping for female light years that lesser can't evening heaven isn't bearing tree appear</p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="single-feature text-center item-padding mt-4 mt-lg-0">
                                <img src="<?php echo MEDINO_ASSETS_URL; ?>/images/feature4.png" alt="">
                                <h3>friendly staff</h3>
                                <p class="pt-3">Creeping for female light years that lesser can't evening heaven isn't bearing tree appear</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Feature Area End -->

            <!-- Welcome Area Starts -->
            <section class="welcome-area section-padding3">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-5 align-self-center">
                            <div class="welcome-img">
                                <img src="<?php echo MEDINO_ASSETS_URL; ?>/images/welcome.png" alt="">
                            </div>
                        </div>
                        <div class="col-lg-7">
                            <div class="welcome-text mt-5 mt-lg-0">
                                <h2>Welcome to our clinic</h2>
                                <p class="pt-3">Subdue whales void god which living don't midst lesser yielding over lights whose. Cattle greater brought sixth fly den dry good tree isn't seed stars were.</p>
                                <p>Subdue whales void god which living don't midst lesser yielding over lights whose. Cattle greater brought sixth fly den dry good tree isn't seed stars were the boring.</p>
                                <a href="#" class="template-btn mt-3">learn more</a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Welcome Area End -->

        
            <!-- Hotline Area Starts -->
            <section class="hotline-area text-center section-padding">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <h2>Emergency hotline</h2>
                            <span>(+01) – 256 567 550</span>
                            <p class="pt-3">We provide 24/7 customer support. Please feel free to contact us <br>for emergency case.</p>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Hotline Area End -->
         <?php endwhile; ?>
        
    <?php endif; ?>

<?php get_footer(); ?>