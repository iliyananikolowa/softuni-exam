<!DOCTYPE html>
<html  <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <?php wp_head(); ?>

        <!-- Page Title -->
        <title><?php wp_title( '|', true, 'right' ); ?></title>


        <!-- Favicon -->
        <link rel="shortcut icon" href="assets/images/logo/favicon.png" type="image/x-icon">

        <!-- CSS Files -->
        
    </head>
    <body <?php body_class(); ?>>
        <!-- Preloader Starts -->
        <div class="preloader">
            <div class="spinner"></div>
        </div>
        <!-- Preloader End -->

        <!-- Header Area Starts -->
        <header class="header-area">
            <div class="header-top">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-9 d-md-flex">
                            <h6 class="mr-3"><span class="mr-2"><i class="fa fa-mobile"></i></span> call us now! +1 305 708 2563</h6>
                            <h6 class="mr-3"><span class="mr-2"><i class="fa fa-envelope-o"></i></span> medical@example.com</h6>
                            <h6><span class="mr-2"><i class="fa fa-map-marker"></i></span> Find our Location</h6>
                        </div>
                        <div class="col-lg-3">
                            <div class="social-links">
                                <ul>
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                    <li><a href="#"><i class="fa fa-vimeo"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="header" id="home">
                <div class="container">
                    <div class="row align-items-center justify-content-between d-flex">
                    <div id="logo">
                        <img src="<?php echo MEDINO_ASSETS_URL; ?>/images/logo/logo.png" alt="" title="" /></a>
                    </div>


             <!-- #nav-menu-container -->
            <?php
                wp_nav_menu( $args = array(
                    'menu'				=> "nav-menu-container", // (int|string|WP_Term) Desired menu. Accepts a menu ID, slug, name, or object.
                    'menu_class'		=> "nav-menu", // (string) CSS class to use for the ul element which forms the menu. Default 'menu'.
                    'menu_id'			=> "nav-menu-container-id", // (string) The ID that is applied to the ul element which forms the menu. Default is the menu slug, incremented.
                    'container'			=> "ul", // (string) Whether to wrap the ul, and what to wrap it with. Default 'div'.
                    'container_class'	=> "container", // (string) Class that is applied to the container. Default 'menu-{menu slug}-container'.
                    'container_id'		=> "nav-menu-container", // (string) The ID that is applied to the container.
                    'theme_location'	=> "header-menu", // (string) Theme location to be used. Must be registered with register_nav_menu() in order to be selectable by the user.
                    
                ) );
            ?>
            <!-- #nav-menu-container -->	
                    
                    </div>
                </div>
            </div>
           
        </header>
        <!-- Header Area End -->

     