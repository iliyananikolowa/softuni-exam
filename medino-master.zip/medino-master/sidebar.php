<div class="sidebar-primary" class="sidebar">
        <?php 
            dynamic_sidebar('sidebar1')                    
        ?>
</div>
             


<div class="sidebar-primary" class="sidebar">
        <?php 
            dynamic_sidebar('sidebar2')                    
        ?>
</div>
             

<div class="sidebar-primary" class="sidebar">
        <?php 
            dynamic_sidebar('sidebar3')                    
        ?>
</div>
             
