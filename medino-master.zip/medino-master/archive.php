<?php get_header(); ?>


    <?php
    $medino_archive_args = array(
        'post_type'         => 'post',
        'post_status'       => 'publish',
        'posts_per_page'    => 15,
        
    );

    $medino_archive_query = new WP_Query ( $medino_archive_args );
    ?>

    <?php if ( $medino_archive_query->have_posts() ) : ?>

    
            <!-- News Area Starts -->
            <section class="text-center section-padding">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            <h1 class="title"><?php the_archive_title(); ?></h1>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <?php while( $medino_archive_query->have_posts() ) : $medino_archive_query->the_post(); ?>

                
                            <div class="col-sm-4">
                                <div class="news-img">
                                    <?php if ( has_post_thumbnail() ) : ?>
                                        <?php the_post_thumbnail(); ?>
                                    <?php else : ?>
                                        <img src="<?php echo MEDINO_ASSETS_URL; ?>/images/default.jpg" alt="" class="img-fluid">
                                    <?php endif; ?>
                                    <h3><a href="blog-details.html"><?php the_title(); ?></a></h3>
                                    <p>Elementum libero hac leo integer. Risus hac part duriw feugiat litora cursus hendrerit bibendum per person on elit.Tempus inceptos posuere me.</p>
                                
                                </div>
                            </div>
        
                    <?php endwhile; ?>
                </div>

                <!-- Pagination -->
                    <div style="text-align:center;">
                        <?php posts_nav_link(' . ', 'previous page', 'next page'); ?>
                    </div>
            </section>

           
    <?php endif; ?>
    <?php wp_reset_postdata(); ?>
<?php get_footer(); ?>

